<?php
	$CONF = array();
	$CONF["host"] = "localhost";
	$CONF["user"] = "qismyirz_freecoin";
	$CONF["pass"] = "jaoY[r[JRv*n";
	$CONF["name"] = "qismyirz_freecoin";
	?>